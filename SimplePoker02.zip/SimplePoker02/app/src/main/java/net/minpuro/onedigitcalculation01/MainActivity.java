package net.minpuro.onedigitcalculation01;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {

    Switch switch1, switch2, switch3, switch4, switch5;
    Switch switch_You1, switch_You2, switch_You3, switch_You4, switch_You5;

    Button buttonChange, buttonStart, buttonAgain;

    TextView textViewNumber1, textViewNumber2, textViewNumber3, textViewNumber4, textViewNumber5;
    TextView textView_YouNumber1, textView_YouNumber2, textView_YouNumber3, textView_YouNumber4, textView_YouNumber5;

    TextView textView1, textView2, textView3, textView4, textView5;  //「かえる」「のこす」
    TextView textView_You1, textView_You2, textView_You3, textView_You4, textView_You5;

    TextView textViewMyResult, textViewYourResult;

    ImageView imageViewMark1, imageViewMark2, imageViewMark3, imageViewMark4, imageViewMark5;
    ImageView imageView_YouMark1, imageView_YouMark2, imageView_YouMark3, imageView_YouMark4, imageView_YouMark5;

    TextView textViewJadge;
    TextView textViewMind;


    int buttonId;
    ArrayList<Integer> arrayList, arrayList2, arrayList3, arrayList4, arrayList5;
    int[] intArray, intArray2, intArray3, intArray4, intArray5;

    int card1, card2, card3, card4, card5;  //自分用
    int card_You1, card_You2, card_You3, card_You4, card_You5;  //あいて用

    String str1, str2, str3, str4, str5;
    String str_You1, str_You2, str_You3, str_You4, str_You5;  //カードを「かえる」「のこす」で使う

    int resultcard1, resultcard2, resultcard3, resultcard4, resultcard5;
    int result_Youcard1, result_Youcard2, result_Youcard3, result_Youcard4, result_Youcard5;

    int sub_s1, sub_s2, sub_s3, sub_s4;
    int sub_s1_You, sub_s2_You, sub_s3_You, sub_s4_You;

    int rImage1, rImage2, rImage3, rImage4, rImage5;
    int rImage_You1, rImage_You2, rImage_You3, rImage_You4, rImage_You5;
    int s_rImage1, s_rImage2, s_rImage3, s_rImage4, s_rImage5;
    int s_rImage1_You, s_rImage2_You, s_rImage3_You, s_rImage4_You, s_rImage5_You;

    int s1, s2, s3, s4, s5;
    int s1_You, s2_You, s3_You, s4_You, s5_You;

    String strMyResult, strYourResult;
    int myPoint, yourPoint;

    Timer timer;
    TimerTask timerTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageViewMark1 = findViewById(R.id.imageViewMark1);
        imageViewMark2 = findViewById(R.id.imageViewMark2);
        imageViewMark3 = findViewById(R.id.imageViewMark3);
        imageViewMark4 = findViewById(R.id.imageViewMark4);
        imageViewMark5 = findViewById(R.id.imageViewMark5);
        imageView_YouMark1 = findViewById(R.id.imageView_YouMark1);
        imageView_YouMark2 = findViewById(R.id.imageView_YouMark2);
        imageView_YouMark3 = findViewById(R.id.imageView_YouMark3);
        imageView_YouMark4 = findViewById(R.id.imageView_YouMark4);
        imageView_YouMark5 = findViewById(R.id.imageView_YouMark5);
        textViewNumber1 = findViewById(R.id.textViewNumber1);
        textViewNumber2 = findViewById(R.id.textViewNumber2);
        textViewNumber3 = findViewById(R.id.textViewNumber3);
        textViewNumber4 = findViewById(R.id.textViewNumber4);
        textViewNumber5 = findViewById(R.id.textViewNumber5);
        textView_YouNumber1 = findViewById(R.id.textView_YouNumber1);
        textView_YouNumber2 = findViewById(R.id.textView_YouNumber2);
        textView_YouNumber3 = findViewById(R.id.textView_YouNumber3);
        textView_YouNumber4 = findViewById(R.id.textView_YouNumber4);
        textView_YouNumber5 = findViewById(R.id.textView_YouNumber5);
        switch1 = findViewById(R.id.switch1);
        switch2 = findViewById(R.id.switch2);
        switch3 = findViewById(R.id.switch3);
        switch4 = findViewById(R.id.switch4);
        switch5 = findViewById(R.id.switch5);
        switch_You1 = findViewById(R.id.switch_You1);
        switch_You2 = findViewById(R.id.switch_You2);
        switch_You3 = findViewById(R.id.switch_You3);
        switch_You4 = findViewById(R.id.switch_You4);
        switch_You5 = findViewById(R.id.switch_You5);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        textView4 = findViewById(R.id.textView4);
        textView5 = findViewById(R.id.textView5);
        textView_You1 = findViewById(R.id.textView_You1);
        textView_You2 = findViewById(R.id.textView_You2);
        textView_You3 = findViewById(R.id.textView_You3);
        textView_You4 = findViewById(R.id.textView_You4);
        textView_You5 = findViewById(R.id.textView_You5);
        textViewMyResult = findViewById(R.id.textViewMyResult);
        textViewYourResult = findViewById(R.id.textViewYourResult);
        buttonStart = findViewById(R.id.buttonStart);
        buttonAgain = findViewById(R.id.buttonAgain);
        buttonChange = findViewById(R.id.buttonChange);
        textViewJadge = findViewById(R.id.textViewJadge);
        textViewMind = findViewById(R.id.textViewMind);


        buttonChange.setOnClickListener(this);
        buttonStart.setOnClickListener(this);
        buttonAgain.setOnClickListener(this);

        switch1.setOnCheckedChangeListener(this);
        switch2.setOnCheckedChangeListener(this);
        switch3.setOnCheckedChangeListener(this);
        switch4.setOnCheckedChangeListener(this);
        switch5.setOnCheckedChangeListener(this);

        //トランプ52枚を用意
        arrayList = new ArrayList<Integer>();
        for (int i = 1; i <= 52; i++) {
            arrayList.add(i);
        }
        //52枚をシャッフル
        Collections.shuffle(arrayList);

        intArray = new int[arrayList.size()];
        //自分用のカード
        intArray[0] = arrayList.get(0);
        intArray[1] = arrayList.get(1);
        intArray[2] = arrayList.get(2);
        intArray[3] = arrayList.get(3);
        intArray[4] = arrayList.get(4);
        intArray[5] = arrayList.get(5);
        intArray[6] = arrayList.get(6);
        intArray[7] = arrayList.get(7);
        intArray[8] = arrayList.get(8);
        intArray[9] = arrayList.get(9);
        //あいて用のカード
        intArray[10] = arrayList.get(1);
        intArray[11] = arrayList.get(11);
        intArray[12] = arrayList.get(12);
        intArray[13] = arrayList.get(13);
        intArray[14] = arrayList.get(14);
        intArray[15] = arrayList.get(15);
        intArray[16] = arrayList.get(16);
        intArray[17] = arrayList.get(17);
        intArray[18] = arrayList.get(18);
        intArray[19] = arrayList.get(19);

        firstDeal();

        buttonStart.setEnabled(false);
        buttonAgain.setEnabled(false);

        //開始1秒後に「勝負」ボタンがONになる
        timer = new Timer();
        timerTask = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        buttonStart.setEnabled(true);
                        textViewMind.setText("！考え中！");
                    }
                });
            }
        };
        timer.schedule(timerTask, 2000);

    }

    private void firstDeal() {

//////////自分用//////////
        //1回目のカード1
        if (intArray[0] >= 40 && intArray[0] < 53) {
            imageViewMark1.setImageResource(R.drawable.clover_20_20);

        } else if (intArray[0] >= 27 && intArray[0] < 40) {
            imageViewMark1.setImageResource(R.drawable.diamond_20_20);

        } else if (intArray[0] >= 14 && intArray[0] < 27) {
            imageViewMark1.setImageResource(R.drawable.heart_20_20);

        } else {
            imageViewMark1.setImageResource(R.drawable.spade_20_20);
        }
        rImage1 = intArray[0];
        card1 = intArray[0] % 13;

        if (card1 == 0) {
            textViewNumber1.setText("13");
        } else {
            textViewNumber1.setText(String.valueOf(card1));
        }

        //1回目のカード2
        if (intArray[1] >= 40 && intArray[1] < 53) {
            imageViewMark2.setImageResource(R.drawable.clover_20_20);

        } else if (intArray[1] >= 27 && intArray[1] < 40) {
            imageViewMark2.setImageResource(R.drawable.diamond_20_20);

        } else if (intArray[1] >= 14 && intArray[1] < 27) {
            imageViewMark2.setImageResource(R.drawable.heart_20_20);

        } else {
            imageViewMark2.setImageResource(R.drawable.spade_20_20);
        }
        rImage2 = intArray[1];
        card2 = intArray[1] % 13;

        if (card2 == 0) {
            textViewNumber2.setText("13");
        } else {
            textViewNumber2.setText(String.valueOf(card2));
        }

        //1回目のカード3
        if (intArray[2] >= 40 && intArray[2] < 53) {
            imageViewMark3.setImageResource(R.drawable.clover_20_20);

        } else if (intArray[2] >= 27 && intArray[2] < 40) {
            imageViewMark3.setImageResource(R.drawable.diamond_20_20);

        } else if (intArray[2] >= 14 && intArray[2] < 27) {
            imageViewMark3.setImageResource(R.drawable.heart_20_20);

        } else {
            imageViewMark3.setImageResource(R.drawable.spade_20_20);
        }
        rImage3 = intArray[2];
        card3 = intArray[2] % 13;

        if (card3 == 0) {
            textViewNumber3.setText("13");
        } else {
            textViewNumber3.setText(String.valueOf(card3));
        }

        //1回目のカード4
        if (intArray[3] >= 40 && intArray[3] < 53) {
            imageViewMark4.setImageResource(R.drawable.clover_20_20);

        } else if (intArray[3] >= 27 && intArray[3] < 40) {
            imageViewMark4.setImageResource(R.drawable.diamond_20_20);

        } else if (intArray[3] >= 14 && intArray[3] < 27) {
            imageViewMark4.setImageResource(R.drawable.heart_20_20);

        } else {
            imageViewMark4.setImageResource(R.drawable.spade_20_20);
        }
        rImage4 = intArray[3];
        card4 = intArray[3] % 13;

        if (card4 == 0) {
            textViewNumber4.setText("13");
        } else {
            textViewNumber4.setText(String.valueOf(card4));
        }

        //1回目のカード5
        if (intArray[4] >= 40 && intArray[4] < 53) {
            imageViewMark5.setImageResource(R.drawable.clover_20_20);

        } else if (intArray[4] >= 27 && intArray[4] < 40) {
            imageViewMark5.setImageResource(R.drawable.diamond_20_20);

        } else if (intArray[4] >= 14 && intArray[4] < 27) {
            imageViewMark5.setImageResource(R.drawable.heart_20_20);

        } else {
            imageViewMark5.setImageResource(R.drawable.spade_20_20);
        }
        rImage5 = intArray[4];
        card5 = intArray[4] % 13;

        if (card5 == 0) {
            textViewNumber5.setText("13");
        } else {
            textViewNumber5.setText(String.valueOf(card5));
        }

//////////あいて用//////////
        //1回目のカード2
        rImage_You1 = intArray[10];
        card_You1 = intArray[10] % 13;

        //1回目のカード2
        rImage_You2 = intArray[11];
        card_You2 = intArray[11] % 13;

        //1回目のカード3
        rImage_You3 = intArray[12];
        card_You3 = intArray[12] % 13;

        //1回目のカード4
        rImage_You4 = intArray[13];
        card_You4 = intArray[13] % 13;

        //1回目のカード5
        rImage_You5 = intArray[14];
        card_You5 = intArray[14] % 13;

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        buttonId = buttonView.getId();

        if (buttonId == R.id.switch1) {
            if (isChecked) {
                textView1.setText("かえる");
            } else {
                textView1.setText("のこす");
            }
        } else if (buttonId == R.id.switch2) {
            if (isChecked) {
                textView2.setText("かえる");
            } else {
                textView2.setText("のこす");
            }
        } else if (buttonId == R.id.switch3) {
            if (isChecked) {
                textView3.setText("かえる");
            } else {
                textView3.setText("のこす");
            }
        } else if (buttonId == R.id.switch4) {
            if (isChecked) {
                textView4.setText("かえる");
            } else {
                textView4.setText("のこす");
            }
        } else if (buttonId == R.id.switch5) {
            if (isChecked) {
                textView5.setText("かえる");
            } else {
                textView5.setText("のこす");
            }
        }

    }

    @Override
    public void onClick(View v) {

        int id = v.getId();

        if (id == R.id.buttonChange) {
            change();
        } else if (id == R.id.buttonStart) {
            textViewMind.setText("");
            Judgment();
            battleResult();
        } else {
            finish();
        }

    }

    private void change () {
        buttonChange.setEnabled(false);
        switch1.setEnabled(false);
        switch2.setEnabled(false);
        switch3.setEnabled(false);
        switch4.setEnabled(false);
        switch5.setEnabled(false);
        switch_You1.setEnabled(false);
        switch_You2.setEnabled(false);
        switch_You3.setEnabled(false);
        switch_You4.setEnabled(false);
        switch_You5.setEnabled(false);

        str1 = String.valueOf(textView1.getText());
        str2 = String.valueOf(textView2.getText());
        str3 = String.valueOf(textView3.getText());
        str4 = String.valueOf(textView4.getText());
        str5 = String.valueOf(textView5.getText());
        str_You1 = String.valueOf(textView_You1.getText());
        str_You2 = String.valueOf(textView_You2.getText());
        str_You3 = String.valueOf(textView_You3.getText());
        str_You4 = String.valueOf(textView_You4.getText());
        str_You5 = String.valueOf(textView_You5.getText());

///////////自分用
        //2回目のカード1
        if (str1.equals("かえる")) {
            imageViewMark1.setVisibility(View.INVISIBLE);

            if (intArray[5] >= 40 && intArray[5] < 53) {
                imageViewMark1.setVisibility(View.VISIBLE);
                imageViewMark1.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[5] >= 27 && intArray[5] < 40) {
                imageViewMark1.setVisibility(View.VISIBLE);
                imageViewMark1.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[5] >= 14 && intArray[5] < 27) {
                imageViewMark1.setVisibility(View.VISIBLE);
                imageViewMark1.setImageResource(R.drawable.heart_20_20);

            } else {
                imageViewMark1.setVisibility(View.VISIBLE);
                imageViewMark1.setImageResource(R.drawable.spade_20_20);
            }
            rImage1 = intArray[5];
            card1 = intArray[5] % 13;

            if (card1 == 0) {
                textViewNumber1.setText("13");
            } else {
                textViewNumber1.setText(String.valueOf(card1));
            }

        }

        //2回目のカード2
        if (str2.equals("かえる")) {
            imageViewMark2.setVisibility(View.INVISIBLE);

            if (intArray[6] >= 40 && intArray[6] < 53) {
                imageViewMark2.setVisibility(View.VISIBLE);
                imageViewMark2.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[6] >= 27 && intArray[6] < 40) {
                imageViewMark2.setVisibility(View.VISIBLE);
                imageViewMark2.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[6] >= 14 && intArray[6] < 27) {
                imageViewMark2.setVisibility(View.VISIBLE);
                imageViewMark2.setImageResource(R.drawable.heart_20_20);

            } else {
                imageViewMark2.setVisibility(View.VISIBLE);
                imageViewMark2.setImageResource(R.drawable.spade_20_20);
            }
            rImage2 = intArray[6];
            card2 = intArray[6] % 13;

            if (card2 == 0) {
                textViewNumber2.setText("13");
            } else {
                textViewNumber2.setText(String.valueOf(card2));
            }

        }

        //2回目のカード3
        if (str3.equals("かえる")) {
            imageViewMark3.setVisibility(View.INVISIBLE);

            if (intArray[7] >= 40 && intArray[7] < 53) {
                imageViewMark3.setVisibility(View.VISIBLE);
                imageViewMark3.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[7] >= 27 && intArray[7] < 40) {
                imageViewMark3.setVisibility(View.VISIBLE);
                imageViewMark3.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[7] >= 14 && intArray[7] < 27) {
                imageViewMark3.setVisibility(View.VISIBLE);
                imageViewMark3.setImageResource(R.drawable.heart_20_20);

            } else {
                imageViewMark3.setVisibility(View.VISIBLE);
                imageViewMark3.setImageResource(R.drawable.spade_20_20);
            }
            rImage3 = intArray[7];
            card3 = intArray[7] % 13;

            if (card3 == 0) {
                textViewNumber3.setText("13");
            } else {
                textViewNumber3.setText(String.valueOf(card3));
            }

        }

        //2回目のカード4
        if (str4.equals("かえる")) {
            imageViewMark4.setVisibility(View.INVISIBLE);

            if (intArray[8] >= 40 && intArray[8] < 53) {
                imageViewMark4.setVisibility(View.VISIBLE);
                imageViewMark4.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[8] >= 27 && intArray[8] < 40) {
                imageViewMark4.setVisibility(View.VISIBLE);
                imageViewMark4.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[8] >= 14 && intArray[8] < 27) {
                imageViewMark4.setVisibility(View.VISIBLE);
                imageViewMark4.setImageResource(R.drawable.heart_20_20);

            } else {
                imageViewMark4.setVisibility(View.VISIBLE);
                imageViewMark4.setImageResource(R.drawable.spade_20_20);
            }
            rImage4 = intArray[8];
            card4 = intArray[8] % 13;

            if (card4 == 0) {
                textViewNumber4.setText("13");
            } else {
                textViewNumber4.setText(String.valueOf(card4));
            }

        }

        //2回目のカード5
        if (str5.equals("かえる")) {
            imageViewMark5.setVisibility(View.INVISIBLE);

            if (intArray[9] >= 40 && intArray[9] < 53) {
                imageViewMark5.setVisibility(View.VISIBLE);
                imageViewMark5.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[9] >= 27 && intArray[9] < 40) {
                imageViewMark5.setVisibility(View.VISIBLE);
                imageViewMark5.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[9] >= 14 && intArray[9] < 27) {
                imageViewMark5.setVisibility(View.VISIBLE);
                imageViewMark5.setImageResource(R.drawable.heart_20_20);

            } else {
                imageViewMark5.setVisibility(View.VISIBLE);
                imageViewMark5.setImageResource(R.drawable.spade_20_20);
            }
            rImage5 = intArray[9];
            card5 = intArray[9] % 13;

            if (card5 == 0) {
                textViewNumber5.setText("13");
            } else {
                textViewNumber5.setText(String.valueOf(card5));
            }

        }



    }

    private void Judgment() {

        buttonStart.setEnabled(false);
        buttonChange.setEnabled(false);
        buttonAgain.setEnabled(true);
        switch1.setEnabled(false);
        switch2.setEnabled(false);
        switch3.setEnabled(false);
        switch4.setEnabled(false);
        switch5.setEnabled(false);
        switch_You1.setEnabled(false);
        switch_You2.setEnabled(false);
        switch_You3.setEnabled(false);
        switch_You4.setEnabled(false);
        switch_You5.setEnabled(false);

        resultcard1 = Integer.parseInt(String.valueOf(textViewNumber1.getText()));
        resultcard2 = Integer.parseInt(String.valueOf(textViewNumber2.getText()));
        resultcard3 = Integer.parseInt(String.valueOf(textViewNumber3.getText()));
        resultcard4 = Integer.parseInt(String.valueOf(textViewNumber4.getText()));
        resultcard5 = Integer.parseInt(String.valueOf(textViewNumber5.getText()));
        result_Youcard1 = Integer.parseInt(String.valueOf(card_You1));
        result_Youcard2 = Integer.parseInt(String.valueOf(card_You2));
        result_Youcard3 = Integer.parseInt(String.valueOf(card_You3));
        result_Youcard4 = Integer.parseInt(String.valueOf(card_You4));
        result_Youcard5 = Integer.parseInt(String.valueOf(card_You5));

//////////自分のカード/////////////
        arrayList2 = new ArrayList<Integer>();

        arrayList2.add(resultcard1);
        arrayList2.add(resultcard2);
        arrayList2.add(resultcard3);
        arrayList2.add(resultcard4);
        arrayList2.add(resultcard5);

        intArray2 = new int[5];

        Collections.sort(arrayList2);  //resultcardを小さい順に並べる

        intArray2[0] = arrayList2.get(0);
        intArray2[1] = arrayList2.get(1);
        intArray2[2] = arrayList2.get(2);
        intArray2[3] = arrayList2.get(3);
        intArray2[4] = arrayList2.get(4);

//////////あいてのカード/////////////
        arrayList3 = new ArrayList<Integer>();

        arrayList3.add(result_Youcard1);
        arrayList3.add(result_Youcard2);
        arrayList3.add(result_Youcard3);
        arrayList3.add(result_Youcard4);
        arrayList3.add(result_Youcard5);

        intArray3 = new int[5];

        Collections.sort(arrayList3);  //result_Youcardを小さい順に並べる

        intArray3[0] = arrayList3.get(0);
        intArray3[1] = arrayList3.get(1);
        intArray3[2] = arrayList3.get(2);
        intArray3[3] = arrayList3.get(3);
        intArray3[4] = arrayList3.get(4);

//////////小さい順に並べ替えた後//////////
        //自分用
        s1 = Integer.parseInt(String.valueOf(intArray2[0]));
        s2 = Integer.parseInt(String.valueOf(intArray2[1]));
        s3 = Integer.parseInt(String.valueOf(intArray2[2]));
        s4 = Integer.parseInt(String.valueOf(intArray2[3]));
        s5 = Integer.parseInt(String.valueOf(intArray2[4]));
        //あいて用
        s1_You = Integer.parseInt(String.valueOf(intArray3[0]));
        s2_You = Integer.parseInt(String.valueOf(intArray3[1]));
        s3_You = Integer.parseInt(String.valueOf(intArray3[2]));
        s4_You = Integer.parseInt(String.valueOf(intArray3[3]));
        s5_You = Integer.parseInt(String.valueOf(intArray3[4]));

        sub_s1 = s2 - s1;
        sub_s2 = s3 - s2;
        sub_s3 = s4 - s3;
        sub_s4 = s5 - s4;
        sub_s1_You = s2_You - s1_You;
        sub_s2_You = s3_You - s2_You;
        sub_s3_You = s4_You - s3_You;
        sub_s4_You = s5_You - s4_You;

/////////////////////////////////
        //自分用(マーク)
        arrayList4 = new ArrayList<Integer>();

        arrayList4.add(rImage1);
        arrayList4.add(rImage2);
        arrayList4.add(rImage3);
        arrayList4.add(rImage4);
        arrayList4.add(rImage5);

        intArray4 = new int[5];

        Collections.sort(arrayList4);

        intArray4[0] = arrayList4.get(0);
        intArray4[1] = arrayList4.get(1);
        intArray4[2] = arrayList4.get(2);
        intArray4[3] = arrayList4.get(3);
        intArray4[4] = arrayList4.get(4);
        s_rImage1 = Integer.parseInt(String.valueOf(intArray4[0]));
        s_rImage2 = Integer.parseInt(String.valueOf(intArray4[1]));
        s_rImage3 = Integer.parseInt(String.valueOf(intArray4[2]));
        s_rImage4 = Integer.parseInt(String.valueOf(intArray4[3]));
        s_rImage5 = Integer.parseInt(String.valueOf(intArray4[4]));

//////////あいて用(マーク)
        arrayList5 = new ArrayList<Integer>();

        arrayList5.add(rImage_You1);
        arrayList5.add(rImage_You2);
        arrayList5.add(rImage_You3);
        arrayList5.add(rImage_You4);
        arrayList5.add(rImage_You5);

        intArray5 = new int[5];

        Collections.sort(arrayList5);

        intArray5[0] = arrayList5.get(0);
        intArray5[1] = arrayList5.get(1);
        intArray5[2] = arrayList5.get(2);
        intArray5[3] = arrayList5.get(3);
        intArray5[4] = arrayList5.get(4);
        s_rImage1_You = Integer.parseInt(String.valueOf(intArray5[0]));
        s_rImage2_You = Integer.parseInt(String.valueOf(intArray5[1]));
        s_rImage3_You = Integer.parseInt(String.valueOf(intArray5[2]));
        s_rImage4_You = Integer.parseInt(String.valueOf(intArray5[3]));
        s_rImage5_You = Integer.parseInt(String.valueOf(intArray5[4]));

        firstRole();

    }

    private void firstRole() {

//////////ロイヤルストレートフラッシュ//////////
        //自分用
        if (s_rImage1 == 40 && s_rImage2 == 49 && s_rImage3 == 50 && s_rImage4 == 51 && s_rImage5 == 52) {
            textViewMyResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1 == 27 && s_rImage2 == 36 && s_rImage3 == 37 && s_rImage4 == 38 && s_rImage5 == 39) {
            textViewMyResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1 == 14 && s_rImage2 == 23 && s_rImage3 == 24 && s_rImage4 == 25 && s_rImage5 == 26) {
            textViewMyResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1 == 1 && s_rImage2 == 10 && s_rImage3 == 11 && s_rImage4 == 12 && s_rImage5 == 13) {
            textViewMyResult.setText("ロイヤルストレートフラッシュ！");
        }

        //あいて用
        if (s_rImage1_You == 40 && s_rImage2_You == 49 && s_rImage3_You == 50 && s_rImage4_You == 51 && s_rImage5_You == 52) {
            textViewYourResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1_You == 27 && s_rImage2_You == 36 && s_rImage3_You == 37 && s_rImage4_You == 38 && s_rImage5_You == 39) {
            textViewYourResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1_You == 14 && s_rImage2_You == 23 && s_rImage3_You == 24 && s_rImage4_You == 25 && s_rImage5_You == 26) {
            textViewYourResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1_You == 1 && s_rImage2_You == 10 && s_rImage3_You == 11 && s_rImage4_You == 12 && s_rImage5_You == 13) {
            textViewYourResult.setText("ロイヤルストレートフラッシュ！");
        }

//////////フラッシュ//////////
        //自分用
        if (s_rImage1 >= 40 && s_rImage5 <= 52) {
            textViewMyResult.setText("フラッシュ！");
        } else if (s_rImage1 >= 27 && s_rImage5 <= 39) {
            textViewMyResult.setText("フラッシュ！");
        } else if (s_rImage1 >= 14 && s_rImage5 <= 26) {
            textViewMyResult.setText("フラッシュ！");
        } else if (s_rImage1 >= 1 && s_rImage5 <= 13) {
            textViewMyResult.setText("フラッシュ！");
        }

        //あいて用
        if (s_rImage1_You >= 40 && s_rImage5_You <= 52) {
            textViewYourResult.setText("フラッシュ！");
        } else if (s_rImage1_You >= 27 && s_rImage5_You <= 39) {
            textViewYourResult.setText("フラッシュ！");
        } else if (s_rImage1_You >= 14 && s_rImage5_You <= 26) {
            textViewYourResult.setText("フラッシュ！");
        } else if (s_rImage1_You >= 1 && s_rImage5_You <= 13) {
            textViewYourResult.setText("フラッシュ！");
        }

//////////ストレート//////////
        //自分用
        if (sub_s1 == 1 && sub_s2 == 1 && sub_s3 == 1 && sub_s4 == 1) {
            textViewMyResult.setText("ストレート！");
        }

        //あいて用
        if (sub_s1_You == 1 && sub_s2_You == 1 && sub_s3_You == 1 && sub_s4_You == 1) {
            textViewYourResult.setText("ストレート！");
        }

//////////ストレートフラッシュ//////////
        //自分用
        if (sub_s1 == 1 && sub_s2 == 1 && sub_s3 == 1 && sub_s4 == 1 && s_rImage1 >= 40 && s_rImage5 <= 52) {
            textViewMyResult.setText("ストレートフラッシュ！");
        } else if (sub_s1 == 1 && sub_s2 == 1 && sub_s3 == 1 && sub_s4 == 1 && s_rImage1 >= 27 && s_rImage5 <= 39) {
            textViewMyResult.setText("ストレートフラッシュ！");
        } else if (sub_s1 == 1 && sub_s2 == 1 && sub_s3 == 1 && sub_s4 == 1 && s_rImage1 >= 14 && s_rImage5 <= 26) {
            textViewMyResult.setText("ストレートフラッシュ！");
        } else if (sub_s1 == 1 && sub_s2 == 1 && sub_s3 == 1 && sub_s4 == 1 && s_rImage1 >= 1 && s_rImage5 <= 13) {
            textViewMyResult.setText("ストレートフラッシュ！");
        }

        //あいて用
        if (sub_s1_You == 1 && sub_s2_You == 1 && sub_s3_You == 1 && sub_s4_You == 1
                && s_rImage1_You >= 40 && s_rImage5_You <= 52) {
            textViewYourResult.setText("ストレートフラッシュ！");

        } else if (sub_s1_You == 1 && sub_s2_You == 1 && sub_s3_You == 1 && sub_s4_You == 1
                && s_rImage1_You >= 27 && s_rImage5_You <= 39) {
            textViewYourResult.setText("ストレートフラッシュ！");

        } else if (sub_s1_You == 1 && sub_s2_You == 1 && sub_s3_You == 1 && sub_s4_You == 1
                && s_rImage1_You >= 14 && s_rImage5_You <= 26) {
            textViewYourResult.setText("ストレートフラッシュ！");

        } else if (sub_s1_You == 1 && sub_s2_You == 1 && sub_s3_You == 1 && sub_s4_You == 1
                && s_rImage1_You >= 1 && s_rImage5_You <= 13) {
            textViewYourResult.setText("ストレートフラッシュ！");

        }

//////////ワンペア//////////
        //自分用
        if (sub_s1 == 0) {
            textViewMyResult.setText("ワンペア！");
        } else if (sub_s2 == 0) {
            textViewMyResult.setText("ワンペア！");
        } else if (sub_s3 == 0) {
            textViewMyResult.setText("ワンペア！");
        } else if (sub_s4 == 0) {
            textViewMyResult.setText("ワンペア！");
        }

        //あいて用
        if (sub_s1_You == 0) {
            textViewYourResult.setText("ワンペア！");
        } else if (sub_s2_You == 0) {
            textViewYourResult.setText("ワンペア！");
        } else if (sub_s3_You == 0) {
            textViewYourResult.setText("ワンペア！");
        } else if (sub_s4_You == 0) {
            textViewYourResult.setText("ワンペア！");
        }

//////////スリーカード//////////
        //自分用
        if (sub_s1 == 0 && sub_s2 == 0) {
            textViewMyResult.setText("スリーカード！");
        } else if (sub_s2 == 0 && sub_s3 == 0) {
            textViewMyResult.setText("スリーカード！");
        } else if (sub_s3 == 0 && sub_s4 == 0) {
            textViewMyResult.setText("スリーカード！");
        }

        //あいて用
        if (sub_s1_You == 0 && sub_s2_You == 0) {
            textViewYourResult.setText("スリーカード！");
        } else if (sub_s2_You == 0 && sub_s3_You == 0) {
            textViewYourResult.setText("スリーカード！");
        } else if (sub_s3_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("スリーカード！");
        }

//////////ツーペア//////////
        //自分用
        if (sub_s1 == 0 && sub_s3 == 0) {
            textViewMyResult.setText("ツーペア！");
        } else if (sub_s1 == 0 && sub_s4 == 0) {
            textViewMyResult.setText("ツーペア！");
        } else if (sub_s2 == 0 && sub_s4 == 0) {
            textViewMyResult.setText("ツーペア！");
        }

        //あいて用
        if (sub_s1_You == 0 && sub_s3_You == 0) {
            textViewYourResult.setText("ツーペア！");
        } else if (sub_s1_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("ツーペア！");
        } else if (sub_s2_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("ツーペア！");
        }

//////////フォーカード//////////
        //自分用
        if (sub_s1 == 0 && sub_s2 == 0 && sub_s3 == 0) {
            textViewMyResult.setText("フォーカード！");
        } else if (sub_s2 == 0 && sub_s3 == 0 && sub_s4 == 0) {
            textViewMyResult.setText("フォーカード！");
        }

        //あいて用
        if (sub_s1_You == 0 && sub_s2_You == 0 && sub_s3_You == 0) {
            textViewYourResult.setText("フォーカード！");
        } else if (sub_s2_You == 0 && sub_s3_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("フォーカード！");
        }

//////////フルハウス//////////
        //自分用
        if (sub_s1 == 0 && sub_s2 == 0 && sub_s4 == 0) {
            textViewMyResult.setText("フルハウス！");
        } else if (sub_s1 == 0 && sub_s3 == 0 && sub_s4 == 0) {
            textViewMyResult.setText("フルハウス！");
        }

        //あいて用
        if (sub_s1_You == 0 && sub_s2_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("フルハウス！");
        } else if (sub_s1_You == 0 && sub_s3_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("フルハウス！");
        }

//////////ハイカード(ブタ)
        strMyResult = String.valueOf(textViewMyResult.getText());

        if (!strMyResult.equals("フラッシュ！") && sub_s1 >= 2 && sub_s2 >= 1 && sub_s3 >= 1 && sub_s4 >= 1
                || !strMyResult.equals("フラッシュ！") && sub_s1 >= 1 && sub_s2 >= 2 && sub_s3 >= 1 && sub_s4 >= 1
                || !strMyResult.equals("フラッシュ！") && sub_s1 >= 1 && sub_s2 >= 1 && sub_s3 >= 2 && sub_s4 >= 1
                || !strMyResult.equals("フラッシュ！") && sub_s1 >= 1 && sub_s2 >= 1 && sub_s3 >= 1 && sub_s4 >= 2) {

            textViewMyResult.setText("ハイカード(ブタ)");
        }


        strYourResult = String.valueOf(textViewYourResult.getText());

        if (!strYourResult.equals("フラッシュ！") && sub_s1_You >= 2 && sub_s2_You >= 1 && sub_s3_You >= 1 && sub_s4_You >= 1
                || !strYourResult.equals("フラッシュ！") && sub_s1_You >= 1 && sub_s2_You >= 2 && sub_s3_You >= 1 && sub_s4_You >= 1
                || !strYourResult.equals("フラッシュ！") && sub_s1_You >= 1 && sub_s2_You >= 1 && sub_s3_You >= 2 && sub_s4_You >= 1
                || !strYourResult.equals("フラッシュ！") && sub_s1_You >= 1 && sub_s2_You >= 1 && sub_s3_You >= 1 && sub_s4_You >= 2) {

            textViewYourResult.setText("ハイカード(ブタ)");
        }

//////////自分の得点
        if (strMyResult.equals("ハイカード(ブタ)")) {
            myPoint = 0;
        } else if (strMyResult.equals("ワンペア！")) {
            myPoint = 100;
        } else if (strMyResult.equals("ツーペア！")) {
            myPoint = 200;
        } else if (strMyResult.equals("スリーカード！")) {
            myPoint = 300;
        } else if (strMyResult.equals("ストレート！")) {
            myPoint = 400;
        } else if (strMyResult.equals("フラッシュ！")) {
            myPoint = 500;
        } else if (strMyResult.equals("フルハウス！")) {
            myPoint = 600;
        } else if (strMyResult.equals("フォーカード！")) {
            myPoint = 700;
        } else if (strMyResult.equals("ストレートフラッシュ！")) {
            myPoint = 800;
        } else if (strMyResult.equals("ロイヤルストレートフラッシュ！")) {
            myPoint = 900;
        }

//////////あいての得点
        if (strYourResult.equals("ハイカード(ブタ)")) {
            yourPoint = 0;
        } else if (strYourResult.equals("ワンペア！")) {
            yourPoint = 100;
        } else if (strYourResult.equals("ツーペア！")) {
            yourPoint = 200;
        } else if (strYourResult.equals("スリーカード！")) {
            yourPoint = 300;
        } else if (strYourResult.equals("ストレート！")) {
            yourPoint = 400;
        } else if (strYourResult.equals("フラッシュ！")) {
            yourPoint = 500;
        } else if (strYourResult.equals("フルハウス！")) {
            yourPoint = 600;
        } else if (strYourResult.equals("フォーカード！")) {
            yourPoint = 700;
        } else if (strYourResult.equals("ストレートフラッシュ！")) {
            yourPoint = 800;
        } else if (strYourResult.equals("ロイヤルストレートフラッシュ！")) {
            yourPoint = 900;
        }


    }

    //TODO あと、スワイプで画面を変えたい。　役の内容とかルールとか。
    private void battleResult() {
        //あいての手札がハイカードのときのみ、1回だけ手札をすべてチェンジさせる
        if (yourPoint == 0) {

            textViewYourResult.setText("");

            textView_You1.setText("かえる");
            textView_You2.setText("かえる");
            textView_You3.setText("かえる");
            textView_You4.setText("かえる");
            textView_You5.setText("かえる");

            imageView_YouMark1.setVisibility(View.INVISIBLE);
            imageView_YouMark2.setVisibility(View.INVISIBLE);
            imageView_YouMark3.setVisibility(View.INVISIBLE);
            imageView_YouMark4.setVisibility(View.INVISIBLE);
            imageView_YouMark5.setVisibility(View.INVISIBLE);

            //2回目のカード1
            if (intArray[15] >= 40 && intArray[15] < 53) {
                imageView_YouMark1.setVisibility(View.VISIBLE);
                imageView_YouMark1.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[15] >= 27 && intArray[15] < 40) {
                imageView_YouMark1.setVisibility(View.VISIBLE);
                imageView_YouMark1.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[15] >= 14 && intArray[15] < 27) {
                imageView_YouMark1.setVisibility(View.VISIBLE);
                imageView_YouMark1.setImageResource(R.drawable.heart_20_20);

            } else {
                imageView_YouMark1.setVisibility(View.VISIBLE);
                imageView_YouMark1.setImageResource(R.drawable.spade_20_20);
            }
            rImage_You1 = intArray[15];
            card_You1 = intArray[15] % 13;

            if (card_You1 == 0) {
                textView_YouNumber1.setText("13");
            } else {
                textView_YouNumber1.setText(String.valueOf(card_You1));
            }

            //2回目のカード2
            if (intArray[16] >= 40 && intArray[16] < 53) {
                imageView_YouMark2.setVisibility(View.VISIBLE);
                imageView_YouMark2.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[16] >= 27 && intArray[16] < 40) {
                imageView_YouMark2.setVisibility(View.VISIBLE);
                imageView_YouMark2.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[16] >= 14 && intArray[16] < 27) {
                imageView_YouMark2.setVisibility(View.VISIBLE);
                imageView_YouMark2.setImageResource(R.drawable.heart_20_20);

            } else {
                imageView_YouMark2.setVisibility(View.VISIBLE);
                imageView_YouMark2.setImageResource(R.drawable.spade_20_20);
            }
            rImage_You2 = intArray[16];
            card_You2 = intArray[16] % 13;

            if (card_You2 == 0) {
                textView_YouNumber2.setText("13");
            } else {
                textView_YouNumber2.setText(String.valueOf(card_You2));
            }

            //2回目のカード3
            if (intArray[17] >= 40 && intArray[17] < 53) {
                imageView_YouMark3.setVisibility(View.VISIBLE);
                imageView_YouMark3.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[17] >= 27 && intArray[17] < 40) {
                imageView_YouMark3.setVisibility(View.VISIBLE);
                imageView_YouMark3.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[17] >= 14 && intArray[17] < 27) {
                imageView_YouMark3.setVisibility(View.VISIBLE);
                imageView_YouMark3.setImageResource(R.drawable.heart_20_20);

            } else {
                imageView_YouMark3.setVisibility(View.VISIBLE);
                imageView_YouMark3.setImageResource(R.drawable.spade_20_20);
            }
            rImage_You3 = intArray[17];
            card_You3 = intArray[17] % 13;

            if (card_You3 == 0) {
                textView_YouNumber3.setText("13");
            } else {
                textView_YouNumber3.setText(String.valueOf(card_You3));
            }

            //2回目のカード4
            if (intArray[18] >= 40 && intArray[18] < 53) {
                imageView_YouMark4.setVisibility(View.VISIBLE);
                imageView_YouMark4.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[18] >= 27 && intArray[18] < 40) {
                imageView_YouMark4.setVisibility(View.VISIBLE);
                imageView_YouMark4.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[18] >= 14 && intArray[18] < 27) {
                imageView_YouMark4.setVisibility(View.VISIBLE);
                imageView_YouMark4.setImageResource(R.drawable.heart_20_20);

            } else {
                imageView_YouMark4.setVisibility(View.VISIBLE);
                imageView_YouMark4.setImageResource(R.drawable.spade_20_20);
            }
            rImage_You4 = intArray[18];
            card_You4 = intArray[18] % 13;

            if (card_You4 == 0) {
                textView_YouNumber4.setText("13");
            } else {
                textView_YouNumber4.setText(String.valueOf(card_You4));
            }

            //2回目のカード5
            if (intArray[19] >= 40 && intArray[19] < 53) {
                imageView_YouMark5.setVisibility(View.VISIBLE);
                imageView_YouMark5.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[19] >= 27 && intArray[19] < 40) {
                imageView_YouMark5.setVisibility(View.VISIBLE);
                imageView_YouMark5.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[19] >= 14 && intArray[19] < 27) {
                imageView_YouMark5.setVisibility(View.VISIBLE);
                imageView_YouMark5.setImageResource(R.drawable.heart_20_20);

            } else {
                imageView_YouMark5.setVisibility(View.VISIBLE);
                imageView_YouMark5.setImageResource(R.drawable.spade_20_20);
            }
            rImage_You5 = intArray[19];
            card_You5 = intArray[19] % 13;

            if (card_You5 == 0) {
                textView_YouNumber5.setText("13");
            } else {
                textView_YouNumber5.setText(String.valueOf(card_You5));
            }

            secondRole();

        } else {
            //1回目のカード1
            if (intArray[10] >= 40 && intArray[10] < 53) {
                imageView_YouMark1.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[10] >= 27 && intArray[10] < 40) {
                imageView_YouMark1.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[10] >= 14 && intArray[10] < 27) {
                imageView_YouMark1.setImageResource(R.drawable.heart_20_20);

            } else {
                imageView_YouMark1.setImageResource(R.drawable.spade_20_20);
            }
            if (card_You1 == 0) {
                textView_YouNumber1.setText("13");
            } else {
                textView_YouNumber1.setText(String.valueOf(card_You1));
            }

            //1回目のカード2
            if (intArray[11] >= 40 && intArray[11] < 53) {
                imageView_YouMark2.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[11] >= 27 && intArray[11] < 40) {
                imageView_YouMark2.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[11] >= 14 && intArray[11] < 27) {
                imageView_YouMark2.setImageResource(R.drawable.heart_20_20);

            } else {
                imageView_YouMark2.setImageResource(R.drawable.spade_20_20);
            }
            if (card_You2 == 0) {
                textView_YouNumber2.setText("13");
            } else {
                textView_YouNumber2.setText(String.valueOf(card_You2));
            }

            //1回目のカード3
            if (intArray[12] >= 40 && intArray[12] < 53) {
                imageView_YouMark3.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[12] >= 27 && intArray[12] < 40) {
                imageView_YouMark3.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[12] >= 14 && intArray[12] < 27) {
                imageView_YouMark3.setImageResource(R.drawable.heart_20_20);

            } else {
                imageView_YouMark3.setImageResource(R.drawable.spade_20_20);
            }
            if (card_You3 == 0) {
                textView_YouNumber3.setText("13");
            } else {
                textView_YouNumber3.setText(String.valueOf(card_You3));
            }

            //1回目のカード4
            if (intArray[13] >= 40 && intArray[13] < 53) {
                imageView_YouMark4.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[13] >= 27 && intArray[13] < 40) {
                imageView_YouMark4.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[13] >= 14 && intArray[13] < 27) {
                imageView_YouMark4.setImageResource(R.drawable.heart_20_20);

            } else {
                imageView_YouMark4.setImageResource(R.drawable.spade_20_20);
            }
            if (card_You4 == 0) {
                textView_YouNumber4.setText("13");
            } else {
                textView_YouNumber4.setText(String.valueOf(card_You4));
            }

            //1回目のカード5
            if (intArray[14] >= 40 && intArray[14] < 53) {
                imageView_YouMark5.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[14] >= 27 && intArray[14] < 40) {
                imageView_YouMark5.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[14] >= 14 && intArray[14] < 27) {
                imageView_YouMark5.setImageResource(R.drawable.heart_20_20);

            } else {
                imageView_YouMark5.setImageResource(R.drawable.spade_20_20);
            }
            if (card_You5 == 0) {
                textView_YouNumber5.setText("13");
            } else {
                textView_YouNumber5.setText(String.valueOf(card_You5));
            }

        }

        if (myPoint > yourPoint) {
            textViewJadge.setText("あなたの勝ちです！");
        } else if (myPoint == yourPoint) {
            textViewJadge.setText("引き分けです！");
        } else {
            textViewJadge.setText("あなたの負けです");
        }

    }

    private void secondRole() {
        //あいて用
        result_Youcard1 = Integer.parseInt(String.valueOf(card_You1));
        result_Youcard2 = Integer.parseInt(String.valueOf(card_You2));
        result_Youcard3 = Integer.parseInt(String.valueOf(card_You3));
        result_Youcard4 = Integer.parseInt(String.valueOf(card_You4));
        result_Youcard5 = Integer.parseInt(String.valueOf(card_You5));

//////////あいてのカード/////////////
        arrayList3 = new ArrayList<Integer>();

        arrayList3.add(result_Youcard1);
        arrayList3.add(result_Youcard2);
        arrayList3.add(result_Youcard3);
        arrayList3.add(result_Youcard4);
        arrayList3.add(result_Youcard5);

        intArray3 = new int[5];

        Collections.sort(arrayList3);  //result_Youcardを小さい順に並べる

        intArray3[0] = arrayList3.get(0);
        intArray3[1] = arrayList3.get(1);
        intArray3[2] = arrayList3.get(2);
        intArray3[3] = arrayList3.get(3);
        intArray3[4] = arrayList3.get(4);

//////////小さい順に並べ替えた後//////////
        //あいて用
        s1_You = Integer.parseInt(String.valueOf(intArray3[0]));
        s2_You = Integer.parseInt(String.valueOf(intArray3[1]));
        s3_You = Integer.parseInt(String.valueOf(intArray3[2]));
        s4_You = Integer.parseInt(String.valueOf(intArray3[3]));
        s5_You = Integer.parseInt(String.valueOf(intArray3[4]));

        sub_s1_You = s2_You - s1_You;
        sub_s2_You = s3_You - s2_You;
        sub_s3_You = s4_You - s3_You;
        sub_s4_You = s5_You - s4_You;

//////////あいて用(マーク)
        arrayList5 = new ArrayList<Integer>();

        arrayList5.add(rImage_You1);
        arrayList5.add(rImage_You2);
        arrayList5.add(rImage_You3);
        arrayList5.add(rImage_You4);
        arrayList5.add(rImage_You5);

        intArray5 = new int[5];

        Collections.sort(arrayList5);

        intArray5[0] = arrayList5.get(0);
        intArray5[1] = arrayList5.get(1);
        intArray5[2] = arrayList5.get(2);
        intArray5[3] = arrayList5.get(3);
        intArray5[4] = arrayList5.get(4);
        s_rImage1_You = Integer.parseInt(String.valueOf(intArray5[0]));
        s_rImage2_You = Integer.parseInt(String.valueOf(intArray5[1]));
        s_rImage3_You = Integer.parseInt(String.valueOf(intArray5[2]));
        s_rImage4_You = Integer.parseInt(String.valueOf(intArray5[3]));
        s_rImage5_You = Integer.parseInt(String.valueOf(intArray5[4]));


//////////ロイヤルストレートフラッシュ//////////
        if (s_rImage1_You == 40 && s_rImage2_You == 49 && s_rImage3_You == 50 && s_rImage4_You == 51 && s_rImage5_You == 52) {
            textViewYourResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1_You == 27 && s_rImage2_You == 36 && s_rImage3_You == 37 && s_rImage4_You == 38 && s_rImage5_You == 39) {
            textViewYourResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1_You == 14 && s_rImage2_You == 23 && s_rImage3_You == 24 && s_rImage4_You == 25 && s_rImage5_You == 26) {
            textViewYourResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1_You == 1 && s_rImage2_You == 10 && s_rImage3_You == 11 && s_rImage4_You == 12 && s_rImage5_You == 13) {
            textViewYourResult.setText("ロイヤルストレートフラッシュ！");
        }

//////////フラッシュ//////////
        if (s_rImage1_You >= 40 && s_rImage5_You <= 52) {
            textViewYourResult.setText("フラッシュ！");
        } else if (s_rImage1_You >= 27 && s_rImage5_You <= 39) {
            textViewYourResult.setText("フラッシュ！");
        } else if (s_rImage1_You >= 14 && s_rImage5_You <= 26) {
            textViewYourResult.setText("フラッシュ！");
        } else if (s_rImage1_You >= 1 && s_rImage5_You <= 13) {
            textViewYourResult.setText("フラッシュ！");
        }

//////////ストレート//////////
        if (sub_s1_You == 1 && sub_s2_You == 1 && sub_s3_You == 1 && sub_s4_You == 1) {
            textViewYourResult.setText("ストレート！");
        }

//////////ストレートフラッシュ//////////
        if (sub_s1_You == 1 && sub_s2_You == 1 && sub_s3_You == 1 && sub_s4_You == 1
                && s_rImage1_You >= 40 && s_rImage5_You <= 52) {
            textViewYourResult.setText("ストレートフラッシュ！");

        } else if (sub_s1_You == 1 && sub_s2_You == 1 && sub_s3_You == 1 && sub_s4_You == 1
                && s_rImage1_You >= 27 && s_rImage5_You <= 39) {
            textViewYourResult.setText("ストレートフラッシュ！");

        } else if (sub_s1_You == 1 && sub_s2_You == 1 && sub_s3_You == 1 && sub_s4_You == 1
                && s_rImage1_You >= 14 && s_rImage5_You <= 26) {
            textViewYourResult.setText("ストレートフラッシュ！");

        } else if (sub_s1_You == 1 && sub_s2_You == 1 && sub_s3_You == 1 && sub_s4_You == 1
                && s_rImage1_You >= 1 && s_rImage5_You <= 13) {
            textViewYourResult.setText("ストレートフラッシュ！");

        }

//////////ワンペア//////////
        if (sub_s1_You == 0) {
            textViewYourResult.setText("ワンペア！");
        } else if (sub_s2_You == 0) {
            textViewYourResult.setText("ワンペア！");
        } else if (sub_s3_You == 0) {
            textViewYourResult.setText("ワンペア！");
        } else if (sub_s4_You == 0) {
            textViewYourResult.setText("ワンペア！");
        }

//////////スリーカード//////////
        if (sub_s1_You == 0 && sub_s2_You == 0) {
            textViewYourResult.setText("スリーカード！");
        } else if (sub_s2_You == 0 && sub_s3_You == 0) {
            textViewYourResult.setText("スリーカード！");
        } else if (sub_s3_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("スリーカード！");
        }

//////////ツーペア//////////
        if (sub_s1_You == 0 && sub_s3_You == 0) {
            textViewYourResult.setText("ツーペア！");
        } else if (sub_s1_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("ツーペア！");
        } else if (sub_s2_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("ツーペア！");
        }

//////////フォーカード//////////
        if (sub_s1_You == 0 && sub_s2_You == 0 && sub_s3_You == 0) {
            textViewYourResult.setText("フォーカード！");
        } else if (sub_s2_You == 0 && sub_s3_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("フォーカード！");
        }

//////////フルハウス//////////
        if (sub_s1_You == 0 && sub_s2_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("フルハウス！");
        } else if (sub_s1_You == 0 && sub_s3_You == 0 && sub_s4_You == 0) {
            textViewYourResult.setText("フルハウス！");
        }

//////////ハイカード(ブタ)
        strYourResult = String.valueOf(textViewYourResult.getText());

        if (!strYourResult.equals("フラッシュ！") && sub_s1_You >= 2 && sub_s2_You >= 1 && sub_s3_You >= 1 && sub_s4_You >= 1
                || !strYourResult.equals("フラッシュ！") && sub_s1_You >= 1 && sub_s2_You >= 2 && sub_s3_You >= 1 && sub_s4_You >= 1
                || !strYourResult.equals("フラッシュ！") && sub_s1_You >= 1 && sub_s2_You >= 1 && sub_s3_You >= 2 && sub_s4_You >= 1
                || !strYourResult.equals("フラッシュ！") && sub_s1_You >= 1 && sub_s2_You >= 1 && sub_s3_You >= 1 && sub_s4_You >= 2) {

            textViewYourResult.setText("ハイカード(ブタ)");
        }

//////////あいての得点
        if (strYourResult.equals("ハイカード(ブタ)")) {
            yourPoint = 0;
        } else if (strYourResult.equals("ワンペア！")) {
            yourPoint = 100;
        } else if (strYourResult.equals("ツーペア！")) {
            yourPoint = 200;
        } else if (strYourResult.equals("スリーカード！")) {
            yourPoint = 300;
        } else if (strYourResult.equals("ストレート！")) {
            yourPoint = 400;
        } else if (strYourResult.equals("フラッシュ！")) {
            yourPoint = 500;
        } else if (strYourResult.equals("フルハウス！")) {
            yourPoint = 600;
        } else if (strYourResult.equals("フォーカード！")) {
            yourPoint = 700;
        } else if (strYourResult.equals("ストレートフラッシュ！")) {
            yourPoint = 800;
        } else if (strYourResult.equals("ロイヤルストレートフラッシュ！")) {
            yourPoint = 900;
        }

    }

}
