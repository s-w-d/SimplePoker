package net.minpuro.onedigitcalculation01;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {

    Switch switch1, switch2, switch3, switch4, switch5;
    Button buttonChange, buttonStart, buttonAgain;
    TextView textViewNumber1, textViewNumber2, textViewNumber3, textViewNumber4, textViewNumber5;
    TextView textView1, textView2, textView3, textView4, textView5;
    TextView textViewResult;
    ImageView imageViewMark1, imageViewMark2, imageViewMark3, imageViewMark4, imageViewMark5;

    int buttonId;
    ArrayList<Integer> arrayList, arrayList2, arrayList3;
    int[] intArray, intArray2, intArray3;
    int card1, card2, card3, card4, card5, card6, card7, card8, card9, card10;
    String str1, str2, str3, str4, str5;
    int resultcard1, resultcard2, resultcard3, resultcard4, resultcard5;
    int rImage1, rImage2, rImage3, rImage4, rImage5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageViewMark1 = findViewById(R.id.imageViewMark1);
        imageViewMark2 = findViewById(R.id.imageViewMark2);
        imageViewMark3 = findViewById(R.id.imageViewMark3);
        imageViewMark4 = findViewById(R.id.imageViewMark4);
        imageViewMark5 = findViewById(R.id.imageViewMark5);
        textViewNumber1 = findViewById(R.id.textViewNumber1);
        textViewNumber2 = findViewById(R.id.textViewNumber2);
        textViewNumber3 = findViewById(R.id.textViewNumber3);
        textViewNumber4 = findViewById(R.id.textViewNumber4);
        textViewNumber5 = findViewById(R.id.textViewNumber5);
        switch1 = findViewById(R.id.switch1);
        switch2 = findViewById(R.id.switch2);
        switch3 = findViewById(R.id.switch3);
        switch4 = findViewById(R.id.switch4);
        switch5 = findViewById(R.id.switch5);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        textView4 = findViewById(R.id.textView4);
        textView5 = findViewById(R.id.textView5);
        textViewResult = findViewById(R.id.textViewResult);
        buttonStart = findViewById(R.id.buttonStart);
        buttonAgain = findViewById(R.id.buttonAgain);
        buttonChange = findViewById(R.id.buttonChange);


        buttonChange.setOnClickListener(this);
        buttonStart.setOnClickListener(this);
        buttonAgain.setOnClickListener(this);
        switch1.setOnCheckedChangeListener(this);
        switch2.setOnCheckedChangeListener(this);
        switch3.setOnCheckedChangeListener(this);
        switch4.setOnCheckedChangeListener(this);
        switch5.setOnCheckedChangeListener(this);


        arrayList = new ArrayList<Integer>();
        for (int i = 1; i <= 52; i++) {
            arrayList.add(i);
        }
        Collections.shuffle(arrayList);

        intArray = new int[arrayList.size()];

        intArray[0] = arrayList.get(0);
        intArray[1] = arrayList.get(1);
        intArray[2] = arrayList.get(2);
        intArray[3] = arrayList.get(3);
        intArray[4] = arrayList.get(4);
        intArray[5] = arrayList.get(5);
        intArray[6] = arrayList.get(6);
        intArray[7] = arrayList.get(7);
        intArray[8] = arrayList.get(8);
        intArray[9] = arrayList.get(9);

        firstDeal();

        buttonAgain.setEnabled(false);

    }

    private void firstDeal() {

        //1回目のカード1
        if (intArray[0] >= 40 && intArray[0] < 53) {
            imageViewMark1.setImageResource(R.drawable.clover_20_20);

        } else if (intArray[0] >= 27 && intArray[0] < 40) {
            imageViewMark1.setImageResource(R.drawable.diamond_20_20);

        } else if (intArray[0] >= 14 && intArray[0] < 27) {
            imageViewMark1.setImageResource(R.drawable.heart_20_20);

        } else {
            imageViewMark1.setImageResource(R.drawable.spade_20_20);
        }
        rImage1 = intArray[0];
        card1 = intArray[0] % 13;

        if (card1 == 0) {
            textViewNumber1.setText("13");
        } else {
            textViewNumber1.setText(String.valueOf(card1));
        }

        //1回目のカード2
        if (intArray[1] >= 40 && intArray[1] < 53) {
            imageViewMark2.setImageResource(R.drawable.clover_20_20);

        } else if (intArray[1] >= 27 && intArray[1] < 40) {
            imageViewMark2.setImageResource(R.drawable.diamond_20_20);

        } else if (intArray[1] >= 14 && intArray[1] < 27) {
            imageViewMark2.setImageResource(R.drawable.heart_20_20);

        } else {
            imageViewMark2.setImageResource(R.drawable.spade_20_20);
        }
        rImage2 = intArray[1];
        card2 = intArray[1] % 13;

        if (card2 == 0) {
            textViewNumber2.setText("13");
        } else {
            textViewNumber2.setText(String.valueOf(card2));
        }

        //1回目のカード3
        if (intArray[2] >= 40 && intArray[2] < 53) {
            imageViewMark3.setImageResource(R.drawable.clover_20_20);

        } else if (intArray[2] >= 27 && intArray[2] < 40) {
            imageViewMark3.setImageResource(R.drawable.diamond_20_20);

        } else if (intArray[2] >= 14 && intArray[2] < 27) {
            imageViewMark3.setImageResource(R.drawable.heart_20_20);

        } else {
            imageViewMark3.setImageResource(R.drawable.spade_20_20);
        }
        rImage3 = intArray[2];
        card3 = intArray[2] % 13;

        if (card3 == 0) {
            textViewNumber3.setText("13");
        } else {
            textViewNumber3.setText(String.valueOf(card3));
        }

        //1回目のカード4
        if (intArray[3] >= 40 && intArray[3] < 53) {
            imageViewMark4.setImageResource(R.drawable.clover_20_20);

        } else if (intArray[3] >= 27 && intArray[3] < 40) {
            imageViewMark4.setImageResource(R.drawable.diamond_20_20);

        } else if (intArray[3] >= 14 && intArray[3] < 27) {
            imageViewMark4.setImageResource(R.drawable.heart_20_20);

        } else {
            imageViewMark4.setImageResource(R.drawable.spade_20_20);
        }
        rImage4 = intArray[3];
        card4 = intArray[3] % 13;

        if (card4 == 0) {
            textViewNumber4.setText("13");
        } else {
            textViewNumber4.setText(String.valueOf(card4));
        }

        //1回目のカード5
        if (intArray[4] >= 40 && intArray[4] < 53) {
            imageViewMark5.setImageResource(R.drawable.clover_20_20);

        } else if (intArray[4] >= 27 && intArray[4] < 40) {
            imageViewMark5.setImageResource(R.drawable.diamond_20_20);

        } else if (intArray[4] >= 14 && intArray[4] < 27) {
            imageViewMark5.setImageResource(R.drawable.heart_20_20);

        } else {
            imageViewMark5.setImageResource(R.drawable.spade_20_20);
        }
        rImage5 = intArray[4];
        card5 = intArray[4] % 13;

        if (card5 == 0) {
            textViewNumber5.setText("13");
        } else {
            textViewNumber5.setText(String.valueOf(card5));
        }

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        buttonId = buttonView.getId();

        if (buttonId == R.id.switch1) {
            if (isChecked) {
                textView1.setText("かえる");
            } else {
                textView1.setText("のこす");
            }

        } else if (buttonId == R.id.switch2) {
            if (isChecked) {
                textView2.setText("かえる");
            } else {
                textView2.setText("のこす");
            }

        } else if (buttonId == R.id.switch3) {
            if (isChecked) {
                textView3.setText("かえる");
            } else {
                textView3.setText("のこす");
            }

        } else if (buttonId == R.id.switch4) {
            if (isChecked) {
                textView4.setText("かえる");
            } else {
                textView4.setText("のこす");
            }

        } else if (buttonId == R.id.switch5) {
            if (isChecked) {
                textView5.setText("かえる");
            } else {
                textView5.setText("のこす");
            }
        }

    }

    @Override
    public void onClick(View v) {

        int id = v.getId();

        if (id == R.id.buttonChange) {
            change();
        } else if (id == R.id.buttonStart) {
            Judgment();
        } else {
            finish();
        }

    }

    private void Judgment() {

        buttonStart.setEnabled(false);
        buttonChange.setEnabled(false);
        buttonAgain.setEnabled(true);
        switch1.setEnabled(false);
        switch2.setEnabled(false);
        switch3.setEnabled(false);
        switch4.setEnabled(false);
        switch5.setEnabled(false);

        resultcard1 = Integer.parseInt(String.valueOf(textViewNumber1.getText()));
        resultcard2 = Integer.parseInt(String.valueOf(textViewNumber2.getText()));
        resultcard3 = Integer.parseInt(String.valueOf(textViewNumber3.getText()));
        resultcard4 = Integer.parseInt(String.valueOf(textViewNumber4.getText()));
        resultcard5 = Integer.parseInt(String.valueOf(textViewNumber5.getText()));

///////////////////////
        arrayList2 = new ArrayList<Integer>();

        arrayList2.add(resultcard1);
        arrayList2.add(resultcard2);
        arrayList2.add(resultcard3);
        arrayList2.add(resultcard4);
        arrayList2.add(resultcard5);

        intArray2 = new int[5];

        Collections.sort(arrayList2);  //resultcardを小さい順に並べる

        intArray2[0] = arrayList2.get(0);
        intArray2[1] = arrayList2.get(1);
        intArray2[2] = arrayList2.get(2);
        intArray2[3] = arrayList2.get(3);
        intArray2[4] = arrayList2.get(4);
        int s1 = Integer.parseInt(String.valueOf(intArray2[0]));
        int s2 = Integer.parseInt(String.valueOf(intArray2[1]));
        int s3 = Integer.parseInt(String.valueOf(intArray2[2]));
        int s4 = Integer.parseInt(String.valueOf(intArray2[3]));
        int s5 = Integer.parseInt(String.valueOf(intArray2[4]));

        int sub_s1 = s2 - s1;
        int sub_s2 = s3 - s2;
        int sub_s3 = s4 - s3;
        int sub_s4 = s5 - s4;

/////////////////////////////////
        arrayList3 = new ArrayList<Integer>();

        arrayList3.add(rImage1);
        arrayList3.add(rImage2);
        arrayList3.add(rImage3);
        arrayList3.add(rImage4);
        arrayList3.add(rImage5);

        intArray3 = new int[5];

        Collections.sort(arrayList3);

        intArray3[0] = arrayList3.get(0);
        intArray3[1] = arrayList3.get(1);
        intArray3[2] = arrayList3.get(2);
        intArray3[3] = arrayList3.get(3);
        intArray3[4] = arrayList3.get(4);
        int s_rImage1 = Integer.parseInt(String.valueOf(intArray3[0]));
        int s_rImage2 = Integer.parseInt(String.valueOf(intArray3[1]));
        int s_rImage3 = Integer.parseInt(String.valueOf(intArray3[2]));
        int s_rImage4 = Integer.parseInt(String.valueOf(intArray3[3]));
        int s_rImage5 = Integer.parseInt(String.valueOf(intArray3[4]));


//////////ハイカード(ブタ)
        textViewResult.setText("ハイカード(ブタ)");

//////////ロイヤルストレートフラッシュ
        if (s_rImage1 == 40 && s_rImage2 == 49 && s_rImage3 == 50 && s_rImage4 == 51 && s_rImage5 == 52) {
            textViewResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1 == 27 && s_rImage2 == 36 && s_rImage3 == 37 && s_rImage4 == 38 && s_rImage5 == 39) {
            textViewResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1 == 14 && s_rImage2 == 23 && s_rImage3 == 24 && s_rImage4 == 25 && s_rImage5 == 26) {
            textViewResult.setText("ロイヤルストレートフラッシュ！");
        } else if (s_rImage1 == 1 && s_rImage2 == 10 && s_rImage3 == 11 && s_rImage4 == 12 && s_rImage5 == 13) {
            textViewResult.setText("ロイヤルストレートフラッシュ！");
        }

//////////フラッシュ
        if (s_rImage1 >= 40 && s_rImage5 <= 52) {
            textViewResult.setText("フラッシュ！");
        } else if (s_rImage1 >= 27 && s_rImage5 <= 39) {
            textViewResult.setText("フラッシュ！");
        } else if (s_rImage1 >= 14 && s_rImage5 <= 26) {
            textViewResult.setText("フラッシュ！");
        } else if (s_rImage1 >= 1 && s_rImage5 <= 13) {
            textViewResult.setText("フラッシュ！");
        }

//////////ストレート
        if (sub_s1 == 1 && sub_s2 == 1 && sub_s3 == 1 && sub_s4 == 1) {
            textViewResult.setText("ストレート！");
        }

//////////ストレートフラッシュ
        if (sub_s1 == 1 && sub_s2 == 1 && sub_s3 == 1 && sub_s4 == 1 && s_rImage1 >= 40 && s_rImage5 <= 52) {
            textViewResult.setText("ストレートフラッシュ！");
        } else if (sub_s1 == 1 && sub_s2 == 1 && sub_s3 == 1 && sub_s4 == 1 && s_rImage1 >= 27 && s_rImage5 <= 39) {
            textViewResult.setText("ストレートフラッシュ！");
        } else if (sub_s1 == 1 && sub_s2 == 1 && sub_s3 == 1 && sub_s4 == 1 && s_rImage1 >= 14 && s_rImage5 <= 26) {
            textViewResult.setText("ストレートフラッシュ！");
        } else if (sub_s1 == 1 && sub_s2 == 1 && sub_s3 == 1 && sub_s4 == 1 && s_rImage1 >= 1 && s_rImage5 <= 13) {
            textViewResult.setText("ストレートフラッシュ！");
        }

//////////ワンペア
        if (sub_s1 == 0) {
            textViewResult.setText("ワンペア！");
        } else if (sub_s2 == 0) {
            textViewResult.setText("ワンペア！");
        } else if (sub_s3 == 0) {
            textViewResult.setText("ワンペア！");
        } else if (sub_s4 == 0) {
            textViewResult.setText("ワンペア！");
        }

//////////スリーカード
        if (sub_s1 == 0 && sub_s2 == 0) {
            textViewResult.setText("スリーカード！");
        } else if (sub_s2 == 0 && sub_s3 == 0) {
            textViewResult.setText("スリーカード！");
        } else if (sub_s3 == 0 && sub_s4 == 0) {
            textViewResult.setText("スリーカード！");
        }

//////////TODO ツーペア
        if (sub_s1 == 0 && sub_s3 == 0) {
            textViewResult.setText("ツーペア！");
        } else if (sub_s1 == 0 && sub_s4 == 0) {
            textViewResult.setText("ツーペア！");
        } else if (sub_s2 == 0 && sub_s4 == 0) {
            textViewResult.setText("ツーペア！");
        }

//////////フォーカード
        if (sub_s1 == 0 && sub_s2 == 0 && sub_s3 == 0) {
            textViewResult.setText("フォーカード！");
        } else if (sub_s2 == 0 && sub_s3 == 0 && sub_s4 == 0) {
            textViewResult.setText("フォーカード！");
        }

//////////フルハウス
        if (sub_s1 == 0 && sub_s2 == 0 && sub_s4 == 0) {
            textViewResult.setText("フルハウス！");
        } else if (sub_s1 == 0 && sub_s3 == 0 && sub_s4 == 0) {
            textViewResult.setText("フルハウス！");
        }

//////////ハイカード(ブタ)
//        if (sub_s1 >= 1 && sub_s2 >= 1 && sub_s3 >= 1 && sub_s4 >= 2) {
//            textViewResult.setText("ハイカード(ブタ)");
//        } else if (sub_s1 >= 1 && sub_s2 >= 1 && sub_s3 >= 2 && sub_s4 >= 1) {
//            textViewResult.setText("ハイカード(ブタ)");
//        } else if (sub_s1 >= 1 && sub_s2 >= 2 && sub_s3 >= 1 && sub_s4 >= 1) {
//            textViewResult.setText("ハイカード(ブタ)");
//        } else if (sub_s1 >= 2 && sub_s2 >= 1 && sub_s3 >= 1 && sub_s4 >= 1) {
//            textViewResult.setText("ハイカード(ブタ)");
//        }



    }

    private void change () {
        buttonChange.setEnabled(false);
        switch1.setEnabled(false);
        switch2.setEnabled(false);
        switch3.setEnabled(false);
        switch4.setEnabled(false);
        switch5.setEnabled(false);

        str1 = String.valueOf(textView1.getText());
        str2 = String.valueOf(textView2.getText());
        str3 = String.valueOf(textView3.getText());
        str4 = String.valueOf(textView4.getText());
        str5 = String.valueOf(textView5.getText());


        //2回目のカード1
        if (str1.equals("かえる")) {
            imageViewMark1.setVisibility(View.INVISIBLE);

            if (intArray[5] >= 40 && intArray[5] < 53) {
                imageViewMark1.setVisibility(View.VISIBLE);
                imageViewMark1.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[5] >= 27 && intArray[5] < 40) {
                imageViewMark1.setVisibility(View.VISIBLE);
                imageViewMark1.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[5] >= 14 && intArray[5] < 27) {
                imageViewMark1.setVisibility(View.VISIBLE);
                imageViewMark1.setImageResource(R.drawable.heart_20_20);

            } else {
                imageViewMark1.setVisibility(View.VISIBLE);
                imageViewMark1.setImageResource(R.drawable.spade_20_20);
            }
            rImage1 = intArray[5];
            card6 = intArray[5] % 13;

            if (card6 == 0) {
                textViewNumber1.setText("13");
            } else {
                textViewNumber1.setText(String.valueOf(card6));
            }

        }

        //2回目のカード2
        if (str2.equals("かえる")) {
            imageViewMark2.setVisibility(View.INVISIBLE);

            if (intArray[6] >= 40 && intArray[6] < 53) {
                imageViewMark2.setVisibility(View.VISIBLE);
                imageViewMark2.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[6] >= 27 && intArray[6] < 40) {
                imageViewMark2.setVisibility(View.VISIBLE);
                imageViewMark2.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[6] >= 14 && intArray[6] < 27) {
                imageViewMark2.setVisibility(View.VISIBLE);
                imageViewMark2.setImageResource(R.drawable.heart_20_20);

            } else {
                imageViewMark2.setVisibility(View.VISIBLE);
                imageViewMark2.setImageResource(R.drawable.spade_20_20);
            }
            rImage2 = intArray[6];
            card7 = intArray[6] % 13;

            if (card7 == 0) {
                textViewNumber2.setText("13");
            } else {
                textViewNumber2.setText(String.valueOf(card7));
            }

        }

        //2回目のカード3
        if (str3.equals("かえる")) {
            imageViewMark3.setVisibility(View.INVISIBLE);

            if (intArray[7] >= 40 && intArray[7] < 53) {
                imageViewMark3.setVisibility(View.VISIBLE);
                imageViewMark3.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[7] >= 27 && intArray[7] < 40) {
                imageViewMark3.setVisibility(View.VISIBLE);
                imageViewMark3.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[7] >= 14 && intArray[7] < 27) {
                imageViewMark3.setVisibility(View.VISIBLE);
                imageViewMark3.setImageResource(R.drawable.heart_20_20);

            } else {
                imageViewMark3.setVisibility(View.VISIBLE);
                imageViewMark3.setImageResource(R.drawable.spade_20_20);
            }
            rImage3 = intArray[7];
            card8 = intArray[7] % 13;

            if (card8 == 0) {
                textViewNumber3.setText("13");
            } else {
                textViewNumber3.setText(String.valueOf(card8));
            }

        }

        //2回目のカード4
        if (str4.equals("かえる")) {
            imageViewMark4.setVisibility(View.INVISIBLE);

            if (intArray[8] >= 40 && intArray[8] < 53) {
                imageViewMark4.setVisibility(View.VISIBLE);
                imageViewMark4.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[8] >= 27 && intArray[8] < 40) {
                imageViewMark4.setVisibility(View.VISIBLE);
                imageViewMark4.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[8] >= 14 && intArray[8] < 27) {
                imageViewMark4.setVisibility(View.VISIBLE);
                imageViewMark4.setImageResource(R.drawable.heart_20_20);

            } else {
                imageViewMark4.setVisibility(View.VISIBLE);
                imageViewMark4.setImageResource(R.drawable.spade_20_20);
            }
            rImage4 = intArray[8];
            card9 = intArray[8] % 13;

            if (card9 == 0) {
                textViewNumber4.setText("13");
            } else {
                textViewNumber4.setText(String.valueOf(card9));
            }

        }

        //2回目のカード5
        if (str5.equals("かえる")) {
            imageViewMark5.setVisibility(View.INVISIBLE);

            if (intArray[9] >= 40 && intArray[9] < 53) {
                imageViewMark5.setVisibility(View.VISIBLE);
                imageViewMark5.setImageResource(R.drawable.clover_20_20);

            } else if (intArray[9] >= 27 && intArray[9] < 40) {
                imageViewMark5.setVisibility(View.VISIBLE);
                imageViewMark5.setImageResource(R.drawable.diamond_20_20);

            } else if (intArray[9] >= 14 && intArray[9] < 27) {
                imageViewMark5.setVisibility(View.VISIBLE);
                imageViewMark5.setImageResource(R.drawable.heart_20_20);

            } else {
                imageViewMark5.setVisibility(View.VISIBLE);
                imageViewMark5.setImageResource(R.drawable.spade_20_20);
            }
            rImage5 = intArray[9];
            card10 = intArray[9] % 13;

            if (card10 == 0) {
                textViewNumber5.setText("13");
            } else {
                textViewNumber5.setText(String.valueOf(card10));
            }

        }


    }

}
